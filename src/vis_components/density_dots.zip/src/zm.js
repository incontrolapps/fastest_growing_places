import { writable } from 'svelte/store';

export const zm = writable(1);