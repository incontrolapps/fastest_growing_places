export default [
    {
        "cx": 30,
        "cy": 1,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 29,
        "cy": 2,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 30,
        "cy": 2,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 29,
        "cy": 3,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 30,
        "cy": 3,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 31,
        "cy": 3,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 32,
        "cy": 3,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 29,
        "cy": 4,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 30,
        "cy": 4,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 31,
        "cy": 4,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 32,
        "cy": 4,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 28,
        "cy": 5,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 29,
        "cy": 5,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 30,
        "cy": 5,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 31,
        "cy": 5,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 32,
        "cy": 5,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 27,
        "cy": 6,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 28,
        "cy": 6,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 29,
        "cy": 6,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 30,
        "cy": 6,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 31,
        "cy": 6,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 32,
        "cy": 6,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 26,
        "cy": 7,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 27,
        "cy": 7,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 28,
        "cy": 7,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 29,
        "cy": 7,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 30,
        "cy": 7,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 31,
        "cy": 7,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 32,
        "cy": 7,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 33,
        "cy": 7,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 25,
        "cy": 8,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 26,
        "cy": 8,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 27,
        "cy": 8,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 28,
        "cy": 8,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 29,
        "cy": 8,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 30,
        "cy": 8,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 31,
        "cy": 8,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 32,
        "cy": 8,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 33,
        "cy": 8,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 24,
        "cy": 9,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 25,
        "cy": 9,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 26,
        "cy": 9,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 27,
        "cy": 9,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 28,
        "cy": 9,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 29,
        "cy": 9,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 30,
        "cy": 9,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 31,
        "cy": 9,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 32,
        "cy": 9,
        "r": 1,
        "colour": 43
    },
    {
        "cx": 33,
        "cy": 9,
        "r": 1,
        "colour": 41
    },
    {
        "cx": 23,
        "cy": 10,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 24,
        "cy": 10,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 25,
        "cy": 10,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 26,
        "cy": 10,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 27,
        "cy": 10,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 28,
        "cy": 10,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 29,
        "cy": 10,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 30,
        "cy": 10,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 31,
        "cy": 10,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 32,
        "cy": 10,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 33,
        "cy": 10,
        "r": 1,
        "colour": 33
    },
    {
        "cx": 34,
        "cy": 10,
        "r": 1,
        "colour": 33
    },
    {
        "cx": 22,
        "cy": 11,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 23,
        "cy": 11,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 24,
        "cy": 11,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 25,
        "cy": 11,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 26,
        "cy": 11,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 27,
        "cy": 11,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 28,
        "cy": 11,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 29,
        "cy": 11,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 30,
        "cy": 11,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 31,
        "cy": 11,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 32,
        "cy": 11,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 33,
        "cy": 11,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 34,
        "cy": 11,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 22,
        "cy": 12,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 23,
        "cy": 12,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 24,
        "cy": 12,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 25,
        "cy": 12,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 26,
        "cy": 12,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 27,
        "cy": 12,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 28,
        "cy": 12,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 29,
        "cy": 12,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 30,
        "cy": 12,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 31,
        "cy": 12,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 32,
        "cy": 12,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 33,
        "cy": 12,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 34,
        "cy": 12,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 35,
        "cy": 12,
        "r": 1,
        "colour": 16
    },
    {
        "cx": 21,
        "cy": 13,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 22,
        "cy": 13,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 23,
        "cy": 13,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 24,
        "cy": 13,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 25,
        "cy": 13,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 26,
        "cy": 13,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 27,
        "cy": 13,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 28,
        "cy": 13,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 29,
        "cy": 13,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 30,
        "cy": 13,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 31,
        "cy": 13,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 32,
        "cy": 13,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 33,
        "cy": 13,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 34,
        "cy": 13,
        "r": 1,
        "colour": 16
    },
    {
        "cx": 35,
        "cy": 13,
        "r": 1,
        "colour": 16
    },
    {
        "cx": 36,
        "cy": 13,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 21,
        "cy": 14,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 22,
        "cy": 14,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 23,
        "cy": 14,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 24,
        "cy": 14,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 25,
        "cy": 14,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 26,
        "cy": 14,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 27,
        "cy": 14,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 28,
        "cy": 14,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 29,
        "cy": 14,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 30,
        "cy": 14,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 31,
        "cy": 14,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 32,
        "cy": 14,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 33,
        "cy": 14,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 34,
        "cy": 14,
        "r": 1,
        "colour": 16
    },
    {
        "cx": 35,
        "cy": 14,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 36,
        "cy": 14,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 37,
        "cy": 14,
        "r": 1,
        "colour": 8
    },
    {
        "cx": 38,
        "cy": 14,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 39,
        "cy": 14,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 21,
        "cy": 15,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 22,
        "cy": 15,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 23,
        "cy": 15,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 24,
        "cy": 15,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 25,
        "cy": 15,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 26,
        "cy": 15,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 27,
        "cy": 15,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 28,
        "cy": 15,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 29,
        "cy": 15,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 30,
        "cy": 15,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 31,
        "cy": 15,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 32,
        "cy": 15,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 33,
        "cy": 15,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 34,
        "cy": 15,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 35,
        "cy": 15,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 36,
        "cy": 15,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 37,
        "cy": 15,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 38,
        "cy": 15,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 39,
        "cy": 15,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 22,
        "cy": 16,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 23,
        "cy": 16,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 24,
        "cy": 16,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 25,
        "cy": 16,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 26,
        "cy": 16,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 27,
        "cy": 16,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 28,
        "cy": 16,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 29,
        "cy": 16,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 30,
        "cy": 16,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 31,
        "cy": 16,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 32,
        "cy": 16,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 33,
        "cy": 16,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 34,
        "cy": 16,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 35,
        "cy": 16,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 36,
        "cy": 16,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 37,
        "cy": 16,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 38,
        "cy": 16,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 39,
        "cy": 16,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 40,
        "cy": 16,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 22,
        "cy": 17,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 23,
        "cy": 17,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 24,
        "cy": 17,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 25,
        "cy": 17,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 26,
        "cy": 17,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 27,
        "cy": 17,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 28,
        "cy": 17,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 29,
        "cy": 17,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 30,
        "cy": 17,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 31,
        "cy": 17,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 32,
        "cy": 17,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 33,
        "cy": 17,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 34,
        "cy": 17,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 35,
        "cy": 17,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 36,
        "cy": 17,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 37,
        "cy": 17,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 38,
        "cy": 17,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 39,
        "cy": 17,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 40,
        "cy": 17,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 41,
        "cy": 17,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 23,
        "cy": 18,
        "r": 1,
        "colour": 14
    },
    {
        "cx": 24,
        "cy": 18,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 26,
        "cy": 18,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 27,
        "cy": 18,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 28,
        "cy": 18,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 29,
        "cy": 18,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 30,
        "cy": 18,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 31,
        "cy": 18,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 32,
        "cy": 18,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 33,
        "cy": 18,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 34,
        "cy": 18,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 35,
        "cy": 18,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 36,
        "cy": 18,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 37,
        "cy": 18,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 38,
        "cy": 18,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 39,
        "cy": 18,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 40,
        "cy": 18,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 41,
        "cy": 18,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 23,
        "cy": 19,
        "r": 1,
        "colour": 14
    },
    {
        "cx": 25,
        "cy": 19,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 26,
        "cy": 19,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 27,
        "cy": 19,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 28,
        "cy": 19,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 29,
        "cy": 19,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 30,
        "cy": 19,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 31,
        "cy": 19,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 32,
        "cy": 19,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 33,
        "cy": 19,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 34,
        "cy": 19,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 35,
        "cy": 19,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 36,
        "cy": 19,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 37,
        "cy": 19,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 38,
        "cy": 19,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 39,
        "cy": 19,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 40,
        "cy": 19,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 41,
        "cy": 19,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 26,
        "cy": 20,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 27,
        "cy": 20,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 28,
        "cy": 20,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 29,
        "cy": 20,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 30,
        "cy": 20,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 31,
        "cy": 20,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 32,
        "cy": 20,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 33,
        "cy": 20,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 34,
        "cy": 20,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 35,
        "cy": 20,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 36,
        "cy": 20,
        "r": 1,
        "colour": 13
    },
    {
        "cx": 37,
        "cy": 20,
        "r": 1,
        "colour": 13
    },
    {
        "cx": 38,
        "cy": 20,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 39,
        "cy": 20,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 40,
        "cy": 20,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 41,
        "cy": 20,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 42,
        "cy": 20,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 25,
        "cy": 21,
        "r": 1,
        "colour": 7
    },
    {
        "cx": 26,
        "cy": 21,
        "r": 1,
        "colour": 7
    },
    {
        "cx": 27,
        "cy": 21,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 28,
        "cy": 21,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 29,
        "cy": 21,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 30,
        "cy": 21,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 31,
        "cy": 21,
        "r": 1,
        "colour": 24
    },
    {
        "cx": 32,
        "cy": 21,
        "r": 1,
        "colour": 24
    },
    {
        "cx": 33,
        "cy": 21,
        "r": 1,
        "colour": 23
    },
    {
        "cx": 34,
        "cy": 21,
        "r": 1,
        "colour": 23
    },
    {
        "cx": 35,
        "cy": 21,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 36,
        "cy": 21,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 37,
        "cy": 21,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 38,
        "cy": 21,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 39,
        "cy": 21,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 40,
        "cy": 21,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 41,
        "cy": 21,
        "r": 1,
        "colour": 7
    },
    {
        "cx": 42,
        "cy": 21,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 24,
        "cy": 22,
        "r": 1,
        "colour": 26
    },
    {
        "cx": 25,
        "cy": 22,
        "r": 1,
        "colour": 8
    },
    {
        "cx": 26,
        "cy": 22,
        "r": 1,
        "colour": 17
    },
    {
        "cx": 27,
        "cy": 22,
        "r": 1,
        "colour": 12
    },
    {
        "cx": 28,
        "cy": 22,
        "r": 1,
        "colour": 18
    },
    {
        "cx": 29,
        "cy": 22,
        "r": 1,
        "colour": 13
    },
    {
        "cx": 30,
        "cy": 22,
        "r": 1,
        "colour": 10
    },
    {
        "cx": 31,
        "cy": 22,
        "r": 1,
        "colour": 10
    },
    {
        "cx": 32,
        "cy": 22,
        "r": 1,
        "colour": 24
    },
    {
        "cx": 33,
        "cy": 22,
        "r": 1,
        "colour": 23
    },
    {
        "cx": 34,
        "cy": 22,
        "r": 1,
        "colour": 23
    },
    {
        "cx": 35,
        "cy": 22,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 36,
        "cy": 22,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 37,
        "cy": 22,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 38,
        "cy": 22,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 39,
        "cy": 22,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 40,
        "cy": 22,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 41,
        "cy": 22,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 42,
        "cy": 22,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 43,
        "cy": 22,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 25,
        "cy": 23,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 26,
        "cy": 23,
        "r": 1,
        "colour": 10
    },
    {
        "cx": 27,
        "cy": 23,
        "r": 1,
        "colour": 10
    },
    {
        "cx": 28,
        "cy": 23,
        "r": 1,
        "colour": 18
    },
    {
        "cx": 29,
        "cy": 23,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 30,
        "cy": 23,
        "r": 1,
        "colour": 15
    },
    {
        "cx": 31,
        "cy": 23,
        "r": 1,
        "colour": 10
    },
    {
        "cx": 32,
        "cy": 23,
        "r": 1,
        "colour": 17
    },
    {
        "cx": 33,
        "cy": 23,
        "r": 1,
        "colour": 16
    },
    {
        "cx": 34,
        "cy": 23,
        "r": 1,
        "colour": 17
    },
    {
        "cx": 35,
        "cy": 23,
        "r": 1,
        "colour": 17
    },
    {
        "cx": 36,
        "cy": 23,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 37,
        "cy": 23,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 38,
        "cy": 23,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 39,
        "cy": 23,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 40,
        "cy": 23,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 41,
        "cy": 23,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 42,
        "cy": 23,
        "r": 1,
        "colour": 14
    },
    {
        "cx": 44,
        "cy": 23,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 24,
        "cy": 24,
        "r": 1,
        "colour": 30
    },
    {
        "cx": 25,
        "cy": 24,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 26,
        "cy": 24,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 27,
        "cy": 24,
        "r": 1,
        "colour": 28
    },
    {
        "cx": 28,
        "cy": 24,
        "r": 1,
        "colour": 33
    },
    {
        "cx": 29,
        "cy": 24,
        "r": 1,
        "colour": 30
    },
    {
        "cx": 30,
        "cy": 24,
        "r": 1,
        "colour": 27
    },
    {
        "cx": 31,
        "cy": 24,
        "r": 1,
        "colour": 18
    },
    {
        "cx": 32,
        "cy": 24,
        "r": 1,
        "colour": 17
    },
    {
        "cx": 33,
        "cy": 24,
        "r": 1,
        "colour": 13
    },
    {
        "cx": 34,
        "cy": 24,
        "r": 1,
        "colour": 13
    },
    {
        "cx": 35,
        "cy": 24,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 36,
        "cy": 24,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 37,
        "cy": 24,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 38,
        "cy": 24,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 39,
        "cy": 24,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 40,
        "cy": 24,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 41,
        "cy": 24,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 42,
        "cy": 24,
        "r": 1,
        "colour": 14
    },
    {
        "cx": 43,
        "cy": 24,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 25,
        "cy": 25,
        "r": 1,
        "colour": 28
    },
    {
        "cx": 26,
        "cy": 25,
        "r": 1,
        "colour": 22
    },
    {
        "cx": 27,
        "cy": 25,
        "r": 1,
        "colour": 28
    },
    {
        "cx": 28,
        "cy": 25,
        "r": 1,
        "colour": 30
    },
    {
        "cx": 29,
        "cy": 25,
        "r": 1,
        "colour": 42
    },
    {
        "cx": 30,
        "cy": 25,
        "r": 1,
        "colour": 35
    },
    {
        "cx": 31,
        "cy": 25,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 32,
        "cy": 25,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 33,
        "cy": 25,
        "r": 1,
        "colour": 25
    },
    {
        "cx": 34,
        "cy": 25,
        "r": 1,
        "colour": 25
    },
    {
        "cx": 35,
        "cy": 25,
        "r": 1,
        "colour": 15
    },
    {
        "cx": 36,
        "cy": 25,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 37,
        "cy": 25,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 38,
        "cy": 25,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 39,
        "cy": 25,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 40,
        "cy": 25,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 41,
        "cy": 25,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 42,
        "cy": 25,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 43,
        "cy": 25,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 44,
        "cy": 25,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 15,
        "cy": 26,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 16,
        "cy": 26,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 24,
        "cy": 26,
        "r": 1,
        "colour": 34
    },
    {
        "cx": 25,
        "cy": 26,
        "r": 1,
        "colour": 71
    },
    {
        "cx": 26,
        "cy": 26,
        "r": 1,
        "colour": 28
    },
    {
        "cx": 27,
        "cy": 26,
        "r": 1,
        "colour": 19
    },
    {
        "cx": 28,
        "cy": 26,
        "r": 1,
        "colour": 16
    },
    {
        "cx": 29,
        "cy": 26,
        "r": 1,
        "colour": 72
    },
    {
        "cx": 30,
        "cy": 26,
        "r": 1,
        "colour": 37
    },
    {
        "cx": 31,
        "cy": 26,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 32,
        "cy": 26,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 33,
        "cy": 26,
        "r": 1,
        "colour": 25
    },
    {
        "cx": 34,
        "cy": 26,
        "r": 1,
        "colour": 25
    },
    {
        "cx": 35,
        "cy": 26,
        "r": 1,
        "colour": 15
    },
    {
        "cx": 36,
        "cy": 26,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 37,
        "cy": 26,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 38,
        "cy": 26,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 39,
        "cy": 26,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 40,
        "cy": 26,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 41,
        "cy": 26,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 42,
        "cy": 26,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 43,
        "cy": 26,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 44,
        "cy": 26,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 45,
        "cy": 26,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 14,
        "cy": 27,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 15,
        "cy": 27,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 16,
        "cy": 27,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 17,
        "cy": 27,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 18,
        "cy": 27,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 20,
        "cy": 27,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 21,
        "cy": 27,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 22,
        "cy": 27,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 23,
        "cy": 27,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 24,
        "cy": 27,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 25,
        "cy": 27,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 26,
        "cy": 27,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 27,
        "cy": 27,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 28,
        "cy": 27,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 29,
        "cy": 27,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 30,
        "cy": 27,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 31,
        "cy": 27,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 32,
        "cy": 27,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 33,
        "cy": 27,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 34,
        "cy": 27,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 35,
        "cy": 27,
        "r": 1,
        "colour": 23
    },
    {
        "cx": 36,
        "cy": 27,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 37,
        "cy": 27,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 38,
        "cy": 27,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 39,
        "cy": 27,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 40,
        "cy": 27,
        "r": 1,
        "colour": 41
    },
    {
        "cx": 41,
        "cy": 27,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 42,
        "cy": 27,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 43,
        "cy": 27,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 44,
        "cy": 27,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 45,
        "cy": 27,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 16,
        "cy": 28,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 17,
        "cy": 28,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 18,
        "cy": 28,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 19,
        "cy": 28,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 20,
        "cy": 28,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 21,
        "cy": 28,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 22,
        "cy": 28,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 23,
        "cy": 28,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 24,
        "cy": 28,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 25,
        "cy": 28,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 26,
        "cy": 28,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 27,
        "cy": 28,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 28,
        "cy": 28,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 29,
        "cy": 28,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 30,
        "cy": 28,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 31,
        "cy": 28,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 32,
        "cy": 28,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 33,
        "cy": 28,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 34,
        "cy": 28,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 35,
        "cy": 28,
        "r": 1,
        "colour": 8
    },
    {
        "cx": 36,
        "cy": 28,
        "r": 1,
        "colour": 23
    },
    {
        "cx": 37,
        "cy": 28,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 38,
        "cy": 28,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 39,
        "cy": 28,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 40,
        "cy": 28,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 41,
        "cy": 28,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 42,
        "cy": 28,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 43,
        "cy": 28,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 44,
        "cy": 28,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 45,
        "cy": 28,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 17,
        "cy": 29,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 18,
        "cy": 29,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 19,
        "cy": 29,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 20,
        "cy": 29,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 21,
        "cy": 29,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 22,
        "cy": 29,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 23,
        "cy": 29,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 24,
        "cy": 29,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 25,
        "cy": 29,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 26,
        "cy": 29,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 27,
        "cy": 29,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 28,
        "cy": 29,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 29,
        "cy": 29,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 30,
        "cy": 29,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 31,
        "cy": 29,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 32,
        "cy": 29,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 33,
        "cy": 29,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 34,
        "cy": 29,
        "r": 1,
        "colour": 8
    },
    {
        "cx": 35,
        "cy": 29,
        "r": 1,
        "colour": 8
    },
    {
        "cx": 36,
        "cy": 29,
        "r": 1,
        "colour": 16
    },
    {
        "cx": 37,
        "cy": 29,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 38,
        "cy": 29,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 39,
        "cy": 29,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 40,
        "cy": 29,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 41,
        "cy": 29,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 42,
        "cy": 29,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 43,
        "cy": 29,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 44,
        "cy": 29,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 16,
        "cy": 30,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 17,
        "cy": 30,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 18,
        "cy": 30,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 19,
        "cy": 30,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 20,
        "cy": 30,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 21,
        "cy": 30,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 22,
        "cy": 30,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 23,
        "cy": 30,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 24,
        "cy": 30,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 25,
        "cy": 30,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 26,
        "cy": 30,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 27,
        "cy": 30,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 28,
        "cy": 30,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 29,
        "cy": 30,
        "r": 1,
        "colour": 10
    },
    {
        "cx": 30,
        "cy": 30,
        "r": 1,
        "colour": 44
    },
    {
        "cx": 31,
        "cy": 30,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 32,
        "cy": 30,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 33,
        "cy": 30,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 34,
        "cy": 30,
        "r": 1,
        "colour": 8
    },
    {
        "cx": 35,
        "cy": 30,
        "r": 1,
        "colour": 8
    },
    {
        "cx": 36,
        "cy": 30,
        "r": 1,
        "colour": 70
    },
    {
        "cx": 37,
        "cy": 30,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 38,
        "cy": 30,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 39,
        "cy": 30,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 40,
        "cy": 30,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 41,
        "cy": 30,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 42,
        "cy": 30,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 43,
        "cy": 30,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 44,
        "cy": 30,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 47,
        "cy": 30,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 48,
        "cy": 30,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 49,
        "cy": 30,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 50,
        "cy": 30,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 51,
        "cy": 30,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 52,
        "cy": 30,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 15,
        "cy": 31,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 16,
        "cy": 31,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 17,
        "cy": 31,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 18,
        "cy": 31,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 19,
        "cy": 31,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 20,
        "cy": 31,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 21,
        "cy": 31,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 22,
        "cy": 31,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 23,
        "cy": 31,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 24,
        "cy": 31,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 25,
        "cy": 31,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 26,
        "cy": 31,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 27,
        "cy": 31,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 28,
        "cy": 31,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 29,
        "cy": 31,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 30,
        "cy": 31,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 31,
        "cy": 31,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 32,
        "cy": 31,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 33,
        "cy": 31,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 34,
        "cy": 31,
        "r": 1,
        "colour": 28
    },
    {
        "cx": 35,
        "cy": 31,
        "r": 1,
        "colour": 7
    },
    {
        "cx": 36,
        "cy": 31,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 37,
        "cy": 31,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 38,
        "cy": 31,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 39,
        "cy": 31,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 40,
        "cy": 31,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 41,
        "cy": 31,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 42,
        "cy": 31,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 43,
        "cy": 31,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 44,
        "cy": 31,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 46,
        "cy": 31,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 47,
        "cy": 31,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 48,
        "cy": 31,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 49,
        "cy": 31,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 50,
        "cy": 31,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 51,
        "cy": 31,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 52,
        "cy": 31,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 53,
        "cy": 31,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 14,
        "cy": 32,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 15,
        "cy": 32,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 18,
        "cy": 32,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 19,
        "cy": 32,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 20,
        "cy": 32,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 21,
        "cy": 32,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 22,
        "cy": 32,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 23,
        "cy": 32,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 24,
        "cy": 32,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 25,
        "cy": 32,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 26,
        "cy": 32,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 27,
        "cy": 32,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 28,
        "cy": 32,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 29,
        "cy": 32,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 30,
        "cy": 32,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 31,
        "cy": 32,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 32,
        "cy": 32,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 33,
        "cy": 32,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 34,
        "cy": 32,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 35,
        "cy": 32,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 36,
        "cy": 32,
        "r": 1,
        "colour": 8
    },
    {
        "cx": 37,
        "cy": 32,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 38,
        "cy": 32,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 39,
        "cy": 32,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 40,
        "cy": 32,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 41,
        "cy": 32,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 42,
        "cy": 32,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 43,
        "cy": 32,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 44,
        "cy": 32,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 45,
        "cy": 32,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 46,
        "cy": 32,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 47,
        "cy": 32,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 48,
        "cy": 32,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 49,
        "cy": 32,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 50,
        "cy": 32,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 51,
        "cy": 32,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 52,
        "cy": 32,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 53,
        "cy": 32,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 54,
        "cy": 32,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 18,
        "cy": 33,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 19,
        "cy": 33,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 20,
        "cy": 33,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 21,
        "cy": 33,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 22,
        "cy": 33,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 23,
        "cy": 33,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 24,
        "cy": 33,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 25,
        "cy": 33,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 26,
        "cy": 33,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 27,
        "cy": 33,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 28,
        "cy": 33,
        "r": 1,
        "colour": 11
    },
    {
        "cx": 29,
        "cy": 33,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 30,
        "cy": 33,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 31,
        "cy": 33,
        "r": 1,
        "colour": 21
    },
    {
        "cx": 32,
        "cy": 33,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 33,
        "cy": 33,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 34,
        "cy": 33,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 35,
        "cy": 33,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 36,
        "cy": 33,
        "r": 1,
        "colour": 12
    },
    {
        "cx": 37,
        "cy": 33,
        "r": 1,
        "colour": 12
    },
    {
        "cx": 38,
        "cy": 33,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 39,
        "cy": 33,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 40,
        "cy": 33,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 41,
        "cy": 33,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 42,
        "cy": 33,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 43,
        "cy": 33,
        "r": 1,
        "colour": 10
    },
    {
        "cx": 44,
        "cy": 33,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 45,
        "cy": 33,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 46,
        "cy": 33,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 47,
        "cy": 33,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 48,
        "cy": 33,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 49,
        "cy": 33,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 50,
        "cy": 33,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 51,
        "cy": 33,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 52,
        "cy": 33,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 53,
        "cy": 33,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 54,
        "cy": 33,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 18,
        "cy": 34,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 19,
        "cy": 34,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 20,
        "cy": 34,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 21,
        "cy": 34,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 22,
        "cy": 34,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 23,
        "cy": 34,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 24,
        "cy": 34,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 25,
        "cy": 34,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 26,
        "cy": 34,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 27,
        "cy": 34,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 28,
        "cy": 34,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 29,
        "cy": 34,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 30,
        "cy": 34,
        "r": 1,
        "colour": 29
    },
    {
        "cx": 31,
        "cy": 34,
        "r": 1,
        "colour": 44
    },
    {
        "cx": 32,
        "cy": 34,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 33,
        "cy": 34,
        "r": 1,
        "colour": 11
    },
    {
        "cx": 34,
        "cy": 34,
        "r": 1,
        "colour": 7
    },
    {
        "cx": 35,
        "cy": 34,
        "r": 1,
        "colour": 7
    },
    {
        "cx": 36,
        "cy": 34,
        "r": 1,
        "colour": 13
    },
    {
        "cx": 37,
        "cy": 34,
        "r": 1,
        "colour": 17
    },
    {
        "cx": 38,
        "cy": 34,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 39,
        "cy": 34,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 40,
        "cy": 34,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 41,
        "cy": 34,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 42,
        "cy": 34,
        "r": 1,
        "colour": 10
    },
    {
        "cx": 43,
        "cy": 34,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 44,
        "cy": 34,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 45,
        "cy": 34,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 46,
        "cy": 34,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 47,
        "cy": 34,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 48,
        "cy": 34,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 49,
        "cy": 34,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 50,
        "cy": 34,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 51,
        "cy": 34,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 52,
        "cy": 34,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 53,
        "cy": 34,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 54,
        "cy": 34,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 55,
        "cy": 34,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 18,
        "cy": 35,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 19,
        "cy": 35,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 20,
        "cy": 35,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 21,
        "cy": 35,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 22,
        "cy": 35,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 23,
        "cy": 35,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 24,
        "cy": 35,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 25,
        "cy": 35,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 26,
        "cy": 35,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 27,
        "cy": 35,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 28,
        "cy": 35,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 29,
        "cy": 35,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 30,
        "cy": 35,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 31,
        "cy": 35,
        "r": 1,
        "colour": 63
    },
    {
        "cx": 32,
        "cy": 35,
        "r": 1,
        "colour": 69
    },
    {
        "cx": 33,
        "cy": 35,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 34,
        "cy": 35,
        "r": 1,
        "colour": 13
    },
    {
        "cx": 35,
        "cy": 35,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 36,
        "cy": 35,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 37,
        "cy": 35,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 38,
        "cy": 35,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 39,
        "cy": 35,
        "r": 1,
        "colour": 15
    },
    {
        "cx": 40,
        "cy": 35,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 41,
        "cy": 35,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 42,
        "cy": 35,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 43,
        "cy": 35,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 44,
        "cy": 35,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 45,
        "cy": 35,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 46,
        "cy": 35,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 47,
        "cy": 35,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 48,
        "cy": 35,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 49,
        "cy": 35,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 50,
        "cy": 35,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 51,
        "cy": 35,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 52,
        "cy": 35,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 53,
        "cy": 35,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 54,
        "cy": 35,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 18,
        "cy": 36,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 19,
        "cy": 36,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 20,
        "cy": 36,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 21,
        "cy": 36,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 22,
        "cy": 36,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 23,
        "cy": 36,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 24,
        "cy": 36,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 25,
        "cy": 36,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 26,
        "cy": 36,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 27,
        "cy": 36,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 28,
        "cy": 36,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 29,
        "cy": 36,
        "r": 1,
        "colour": 7
    },
    {
        "cx": 30,
        "cy": 36,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 31,
        "cy": 36,
        "r": 1,
        "colour": 10
    },
    {
        "cx": 32,
        "cy": 36,
        "r": 1,
        "colour": 69
    },
    {
        "cx": 33,
        "cy": 36,
        "r": 1,
        "colour": 20
    },
    {
        "cx": 34,
        "cy": 36,
        "r": 1,
        "colour": 60
    },
    {
        "cx": 35,
        "cy": 36,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 36,
        "cy": 36,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 37,
        "cy": 36,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 38,
        "cy": 36,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 39,
        "cy": 36,
        "r": 1,
        "colour": 7
    },
    {
        "cx": 40,
        "cy": 36,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 41,
        "cy": 36,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 42,
        "cy": 36,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 43,
        "cy": 36,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 44,
        "cy": 36,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 45,
        "cy": 36,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 46,
        "cy": 36,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 47,
        "cy": 36,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 48,
        "cy": 36,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 49,
        "cy": 36,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 50,
        "cy": 36,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 51,
        "cy": 36,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 52,
        "cy": 36,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 53,
        "cy": 36,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 54,
        "cy": 36,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 18,
        "cy": 37,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 19,
        "cy": 37,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 20,
        "cy": 37,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 21,
        "cy": 37,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 22,
        "cy": 37,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 23,
        "cy": 37,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 24,
        "cy": 37,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 25,
        "cy": 37,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 26,
        "cy": 37,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 27,
        "cy": 37,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 28,
        "cy": 37,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 29,
        "cy": 37,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 30,
        "cy": 37,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 31,
        "cy": 37,
        "r": 1,
        "colour": 8
    },
    {
        "cx": 32,
        "cy": 37,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 33,
        "cy": 37,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 34,
        "cy": 37,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 35,
        "cy": 37,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 36,
        "cy": 37,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 37,
        "cy": 37,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 38,
        "cy": 37,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 39,
        "cy": 37,
        "r": 1,
        "colour": 8
    },
    {
        "cx": 40,
        "cy": 37,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 41,
        "cy": 37,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 42,
        "cy": 37,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 43,
        "cy": 37,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 44,
        "cy": 37,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 45,
        "cy": 37,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 46,
        "cy": 37,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 47,
        "cy": 37,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 48,
        "cy": 37,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 49,
        "cy": 37,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 50,
        "cy": 37,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 51,
        "cy": 37,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 52,
        "cy": 37,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 53,
        "cy": 37,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 54,
        "cy": 37,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 17,
        "cy": 38,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 18,
        "cy": 38,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 19,
        "cy": 38,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 20,
        "cy": 38,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 21,
        "cy": 38,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 22,
        "cy": 38,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 23,
        "cy": 38,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 24,
        "cy": 38,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 25,
        "cy": 38,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 26,
        "cy": 38,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 27,
        "cy": 38,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 28,
        "cy": 38,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 29,
        "cy": 38,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 30,
        "cy": 38,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 31,
        "cy": 38,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 32,
        "cy": 38,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 33,
        "cy": 38,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 34,
        "cy": 38,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 35,
        "cy": 38,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 36,
        "cy": 38,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 37,
        "cy": 38,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 38,
        "cy": 38,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 39,
        "cy": 38,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 40,
        "cy": 38,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 41,
        "cy": 38,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 42,
        "cy": 38,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 43,
        "cy": 38,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 44,
        "cy": 38,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 45,
        "cy": 38,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 46,
        "cy": 38,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 47,
        "cy": 38,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 48,
        "cy": 38,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 49,
        "cy": 38,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 50,
        "cy": 38,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 51,
        "cy": 38,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 52,
        "cy": 38,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 53,
        "cy": 38,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 54,
        "cy": 38,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 16,
        "cy": 39,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 17,
        "cy": 39,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 18,
        "cy": 39,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 19,
        "cy": 39,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 20,
        "cy": 39,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 21,
        "cy": 39,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 22,
        "cy": 39,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 23,
        "cy": 39,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 24,
        "cy": 39,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 25,
        "cy": 39,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 26,
        "cy": 39,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 27,
        "cy": 39,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 28,
        "cy": 39,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 29,
        "cy": 39,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 30,
        "cy": 39,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 31,
        "cy": 39,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 32,
        "cy": 39,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 33,
        "cy": 39,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 34,
        "cy": 39,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 35,
        "cy": 39,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 36,
        "cy": 39,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 37,
        "cy": 39,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 38,
        "cy": 39,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 39,
        "cy": 39,
        "r": 1,
        "colour": 15
    },
    {
        "cx": 40,
        "cy": 39,
        "r": 1,
        "colour": 15
    },
    {
        "cx": 41,
        "cy": 39,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 42,
        "cy": 39,
        "r": 1,
        "colour": 7
    },
    {
        "cx": 43,
        "cy": 39,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 44,
        "cy": 39,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 45,
        "cy": 39,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 46,
        "cy": 39,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 47,
        "cy": 39,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 48,
        "cy": 39,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 49,
        "cy": 39,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 50,
        "cy": 39,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 51,
        "cy": 39,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 52,
        "cy": 39,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 53,
        "cy": 39,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 14,
        "cy": 40,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 15,
        "cy": 40,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 16,
        "cy": 40,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 17,
        "cy": 40,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 18,
        "cy": 40,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 19,
        "cy": 40,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 20,
        "cy": 40,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 21,
        "cy": 40,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 22,
        "cy": 40,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 23,
        "cy": 40,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 24,
        "cy": 40,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 25,
        "cy": 40,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 26,
        "cy": 40,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 27,
        "cy": 40,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 28,
        "cy": 40,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 29,
        "cy": 40,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 30,
        "cy": 40,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 31,
        "cy": 40,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 32,
        "cy": 40,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 33,
        "cy": 40,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 34,
        "cy": 40,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 35,
        "cy": 40,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 36,
        "cy": 40,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 37,
        "cy": 40,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 38,
        "cy": 40,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 39,
        "cy": 40,
        "r": 1,
        "colour": 15
    },
    {
        "cx": 40,
        "cy": 40,
        "r": 1,
        "colour": 7
    },
    {
        "cx": 41,
        "cy": 40,
        "r": 1,
        "colour": 7
    },
    {
        "cx": 42,
        "cy": 40,
        "r": 1,
        "colour": 7
    },
    {
        "cx": 43,
        "cy": 40,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 44,
        "cy": 40,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 45,
        "cy": 40,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 46,
        "cy": 40,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 47,
        "cy": 40,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 48,
        "cy": 40,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 49,
        "cy": 40,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 50,
        "cy": 40,
        "r": 1,
        "colour": 10
    },
    {
        "cx": 51,
        "cy": 40,
        "r": 1,
        "colour": 7
    },
    {
        "cx": 52,
        "cy": 40,
        "r": 1,
        "colour": 7
    },
    {
        "cx": 11,
        "cy": 41,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 12,
        "cy": 41,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 13,
        "cy": 41,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 14,
        "cy": 41,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 15,
        "cy": 41,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 16,
        "cy": 41,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 17,
        "cy": 41,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 18,
        "cy": 41,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 19,
        "cy": 41,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 20,
        "cy": 41,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 21,
        "cy": 41,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 22,
        "cy": 41,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 23,
        "cy": 41,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 24,
        "cy": 41,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 25,
        "cy": 41,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 26,
        "cy": 41,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 27,
        "cy": 41,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 28,
        "cy": 41,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 29,
        "cy": 41,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 30,
        "cy": 41,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 31,
        "cy": 41,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 32,
        "cy": 41,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 33,
        "cy": 41,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 34,
        "cy": 41,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 35,
        "cy": 41,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 36,
        "cy": 41,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 37,
        "cy": 41,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 38,
        "cy": 41,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 39,
        "cy": 41,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 40,
        "cy": 41,
        "r": 1,
        "colour": 7
    },
    {
        "cx": 41,
        "cy": 41,
        "r": 1,
        "colour": 15
    },
    {
        "cx": 42,
        "cy": 41,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 43,
        "cy": 41,
        "r": 1,
        "colour": 54
    },
    {
        "cx": 44,
        "cy": 41,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 45,
        "cy": 41,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 46,
        "cy": 41,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 47,
        "cy": 41,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 48,
        "cy": 41,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 49,
        "cy": 41,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 50,
        "cy": 41,
        "r": 1,
        "colour": 10
    },
    {
        "cx": 51,
        "cy": 41,
        "r": 1,
        "colour": 7
    },
    {
        "cx": 52,
        "cy": 41,
        "r": 1,
        "colour": 7
    },
    {
        "cx": 10,
        "cy": 42,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 11,
        "cy": 42,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 12,
        "cy": 42,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 13,
        "cy": 42,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 14,
        "cy": 42,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 15,
        "cy": 42,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 16,
        "cy": 42,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 17,
        "cy": 42,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 18,
        "cy": 42,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 19,
        "cy": 42,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 20,
        "cy": 42,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 21,
        "cy": 42,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 22,
        "cy": 42,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 23,
        "cy": 42,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 24,
        "cy": 42,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 25,
        "cy": 42,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 26,
        "cy": 42,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 27,
        "cy": 42,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 28,
        "cy": 42,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 29,
        "cy": 42,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 30,
        "cy": 42,
        "r": 1,
        "colour": 43
    },
    {
        "cx": 31,
        "cy": 42,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 32,
        "cy": 42,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 33,
        "cy": 42,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 34,
        "cy": 42,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 35,
        "cy": 42,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 36,
        "cy": 42,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 37,
        "cy": 42,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 38,
        "cy": 42,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 39,
        "cy": 42,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 40,
        "cy": 42,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 41,
        "cy": 42,
        "r": 1,
        "colour": 10
    },
    {
        "cx": 42,
        "cy": 42,
        "r": 1,
        "colour": 15
    },
    {
        "cx": 43,
        "cy": 42,
        "r": 1,
        "colour": 15
    },
    {
        "cx": 44,
        "cy": 42,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 45,
        "cy": 42,
        "r": 1,
        "colour": 17
    },
    {
        "cx": 46,
        "cy": 42,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 47,
        "cy": 42,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 48,
        "cy": 42,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 49,
        "cy": 42,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 11,
        "cy": 43,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 12,
        "cy": 43,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 13,
        "cy": 43,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 14,
        "cy": 43,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 15,
        "cy": 43,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 16,
        "cy": 43,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 17,
        "cy": 43,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 18,
        "cy": 43,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 19,
        "cy": 43,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 20,
        "cy": 43,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 21,
        "cy": 43,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 22,
        "cy": 43,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 23,
        "cy": 43,
        "r": 1,
        "colour": 11
    },
    {
        "cx": 24,
        "cy": 43,
        "r": 1,
        "colour": 11
    },
    {
        "cx": 25,
        "cy": 43,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 26,
        "cy": 43,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 27,
        "cy": 43,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 28,
        "cy": 43,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 29,
        "cy": 43,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 30,
        "cy": 43,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 31,
        "cy": 43,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 32,
        "cy": 43,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 33,
        "cy": 43,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 34,
        "cy": 43,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 35,
        "cy": 43,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 36,
        "cy": 43,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 37,
        "cy": 43,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 38,
        "cy": 43,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 39,
        "cy": 43,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 40,
        "cy": 43,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 41,
        "cy": 43,
        "r": 1,
        "colour": 12
    },
    {
        "cx": 42,
        "cy": 43,
        "r": 1,
        "colour": 15
    },
    {
        "cx": 43,
        "cy": 43,
        "r": 1,
        "colour": 16
    },
    {
        "cx": 44,
        "cy": 43,
        "r": 1,
        "colour": 31
    },
    {
        "cx": 45,
        "cy": 43,
        "r": 1,
        "colour": 7
    },
    {
        "cx": 46,
        "cy": 43,
        "r": 1,
        "colour": 8
    },
    {
        "cx": 47,
        "cy": 43,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 48,
        "cy": 43,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 49,
        "cy": 43,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 50,
        "cy": 43,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 12,
        "cy": 44,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 13,
        "cy": 44,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 17,
        "cy": 44,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 18,
        "cy": 44,
        "r": 1,
        "colour": 11
    },
    {
        "cx": 19,
        "cy": 44,
        "r": 1,
        "colour": 11
    },
    {
        "cx": 20,
        "cy": 44,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 21,
        "cy": 44,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 22,
        "cy": 44,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 23,
        "cy": 44,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 24,
        "cy": 44,
        "r": 1,
        "colour": 11
    },
    {
        "cx": 25,
        "cy": 44,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 26,
        "cy": 44,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 27,
        "cy": 44,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 28,
        "cy": 44,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 29,
        "cy": 44,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 30,
        "cy": 44,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 31,
        "cy": 44,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 32,
        "cy": 44,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 33,
        "cy": 44,
        "r": 1,
        "colour": 16
    },
    {
        "cx": 34,
        "cy": 44,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 35,
        "cy": 44,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 36,
        "cy": 44,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 37,
        "cy": 44,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 38,
        "cy": 44,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 39,
        "cy": 44,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 40,
        "cy": 44,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 41,
        "cy": 44,
        "r": 1,
        "colour": 17
    },
    {
        "cx": 42,
        "cy": 44,
        "r": 1,
        "colour": 66
    },
    {
        "cx": 43,
        "cy": 44,
        "r": 1,
        "colour": 72
    },
    {
        "cx": 44,
        "cy": 44,
        "r": 1,
        "colour": 88
    },
    {
        "cx": 45,
        "cy": 44,
        "r": 1,
        "colour": 93
    },
    {
        "cx": 46,
        "cy": 44,
        "r": 1,
        "colour": 36
    },
    {
        "cx": 47,
        "cy": 44,
        "r": 1,
        "colour": 28
    },
    {
        "cx": 48,
        "cy": 44,
        "r": 1,
        "colour": 28
    },
    {
        "cx": 49,
        "cy": 44,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 50,
        "cy": 44,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 17,
        "cy": 45,
        "r": 1,
        "colour": 11
    },
    {
        "cx": 18,
        "cy": 45,
        "r": 1,
        "colour": 11
    },
    {
        "cx": 20,
        "cy": 45,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 21,
        "cy": 45,
        "r": 1,
        "colour": 10
    },
    {
        "cx": 22,
        "cy": 45,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 23,
        "cy": 45,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 24,
        "cy": 45,
        "r": 1,
        "colour": 11
    },
    {
        "cx": 25,
        "cy": 45,
        "r": 1,
        "colour": 12
    },
    {
        "cx": 26,
        "cy": 45,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 27,
        "cy": 45,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 28,
        "cy": 45,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 29,
        "cy": 45,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 30,
        "cy": 45,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 31,
        "cy": 45,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 32,
        "cy": 45,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 33,
        "cy": 45,
        "r": 1,
        "colour": 16
    },
    {
        "cx": 34,
        "cy": 45,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 35,
        "cy": 45,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 36,
        "cy": 45,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 37,
        "cy": 45,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 38,
        "cy": 45,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 39,
        "cy": 45,
        "r": 1,
        "colour": 13
    },
    {
        "cx": 40,
        "cy": 45,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 41,
        "cy": 45,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 42,
        "cy": 45,
        "r": 1,
        "colour": 87
    },
    {
        "cx": 43,
        "cy": 45,
        "r": 1,
        "colour": 205
    },
    {
        "cx": 44,
        "cy": 45,
        "r": 1,
        "colour": 78
    },
    {
        "cx": 45,
        "cy": 45,
        "r": 1,
        "colour": 112
    },
    {
        "cx": 46,
        "cy": 45,
        "r": 1,
        "colour": 17
    },
    {
        "cx": 47,
        "cy": 45,
        "r": 1,
        "colour": 17
    },
    {
        "cx": 48,
        "cy": 45,
        "r": 1,
        "colour": 24
    },
    {
        "cx": 49,
        "cy": 45,
        "r": 1,
        "colour": 23
    },
    {
        "cx": 21,
        "cy": 46,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 22,
        "cy": 46,
        "r": 1,
        "colour": 7
    },
    {
        "cx": 23,
        "cy": 46,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 24,
        "cy": 46,
        "r": 1,
        "colour": 41
    },
    {
        "cx": 27,
        "cy": 46,
        "r": 1,
        "colour": 15
    },
    {
        "cx": 28,
        "cy": 46,
        "r": 1,
        "colour": 30
    },
    {
        "cx": 29,
        "cy": 46,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 30,
        "cy": 46,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 31,
        "cy": 46,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 32,
        "cy": 46,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 33,
        "cy": 46,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 34,
        "cy": 46,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 35,
        "cy": 46,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 36,
        "cy": 46,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 37,
        "cy": 46,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 38,
        "cy": 46,
        "r": 1,
        "colour": 64
    },
    {
        "cx": 39,
        "cy": 46,
        "r": 1,
        "colour": 16
    },
    {
        "cx": 40,
        "cy": 46,
        "r": 1,
        "colour": 16
    },
    {
        "cx": 41,
        "cy": 46,
        "r": 1,
        "colour": 17
    },
    {
        "cx": 42,
        "cy": 46,
        "r": 1,
        "colour": 49
    },
    {
        "cx": 43,
        "cy": 46,
        "r": 1,
        "colour": 86
    },
    {
        "cx": 44,
        "cy": 46,
        "r": 1,
        "colour": 36
    },
    {
        "cx": 45,
        "cy": 46,
        "r": 1,
        "colour": 35
    },
    {
        "cx": 46,
        "cy": 46,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 47,
        "cy": 46,
        "r": 1,
        "colour": 18
    },
    {
        "cx": 48,
        "cy": 46,
        "r": 1,
        "colour": 23
    },
    {
        "cx": 49,
        "cy": 46,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 50,
        "cy": 46,
        "r": 1,
        "colour": 7
    },
    {
        "cx": 52,
        "cy": 46,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 53,
        "cy": 46,
        "r": 1,
        "colour": 23
    },
    {
        "cx": 54,
        "cy": 46,
        "r": 1,
        "colour": 21
    },
    {
        "cx": 22,
        "cy": 47,
        "r": 1,
        "colour": 7
    },
    {
        "cx": 23,
        "cy": 47,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 25,
        "cy": 47,
        "r": 1,
        "colour": 11
    },
    {
        "cx": 26,
        "cy": 47,
        "r": 1,
        "colour": 10
    },
    {
        "cx": 27,
        "cy": 47,
        "r": 1,
        "colour": 10
    },
    {
        "cx": 28,
        "cy": 47,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 29,
        "cy": 47,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 30,
        "cy": 47,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 31,
        "cy": 47,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 32,
        "cy": 47,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 33,
        "cy": 47,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 34,
        "cy": 47,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 35,
        "cy": 47,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 36,
        "cy": 47,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 37,
        "cy": 47,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 38,
        "cy": 47,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 39,
        "cy": 47,
        "r": 1,
        "colour": 8
    },
    {
        "cx": 40,
        "cy": 47,
        "r": 1,
        "colour": 15
    },
    {
        "cx": 41,
        "cy": 47,
        "r": 1,
        "colour": 25
    },
    {
        "cx": 42,
        "cy": 47,
        "r": 1,
        "colour": 24
    },
    {
        "cx": 43,
        "cy": 47,
        "r": 1,
        "colour": 19
    },
    {
        "cx": 44,
        "cy": 47,
        "r": 1,
        "colour": 10
    },
    {
        "cx": 45,
        "cy": 47,
        "r": 1,
        "colour": 27
    },
    {
        "cx": 46,
        "cy": 47,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 47,
        "cy": 47,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 48,
        "cy": 47,
        "r": 1,
        "colour": 8
    },
    {
        "cx": 49,
        "cy": 47,
        "r": 1,
        "colour": 8
    },
    {
        "cx": 50,
        "cy": 47,
        "r": 1,
        "colour": 7
    },
    {
        "cx": 51,
        "cy": 47,
        "r": 1,
        "colour": 8
    },
    {
        "cx": 52,
        "cy": 47,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 53,
        "cy": 47,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 25,
        "cy": 48,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 26,
        "cy": 48,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 27,
        "cy": 48,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 28,
        "cy": 48,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 29,
        "cy": 48,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 30,
        "cy": 48,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 31,
        "cy": 48,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 32,
        "cy": 48,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 33,
        "cy": 48,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 34,
        "cy": 48,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 35,
        "cy": 48,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 36,
        "cy": 48,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 37,
        "cy": 48,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 38,
        "cy": 48,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 39,
        "cy": 48,
        "r": 1,
        "colour": 8
    },
    {
        "cx": 40,
        "cy": 48,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 41,
        "cy": 48,
        "r": 1,
        "colour": 9
    },
    {
        "cx": 42,
        "cy": 48,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 43,
        "cy": 48,
        "r": 1,
        "colour": 8
    },
    {
        "cx": 44,
        "cy": 48,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 45,
        "cy": 48,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 46,
        "cy": 48,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 47,
        "cy": 48,
        "r": 1,
        "colour": 8
    },
    {
        "cx": 48,
        "cy": 48,
        "r": 1,
        "colour": 8
    },
    {
        "cx": 49,
        "cy": 48,
        "r": 1,
        "colour": 8
    },
    {
        "cx": 50,
        "cy": 48,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 51,
        "cy": 48,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 52,
        "cy": 48,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 53,
        "cy": 48,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 18,
        "cy": 49,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 19,
        "cy": 49,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 20,
        "cy": 49,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 21,
        "cy": 49,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 22,
        "cy": 49,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 24,
        "cy": 49,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 25,
        "cy": 49,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 26,
        "cy": 49,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 27,
        "cy": 49,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 28,
        "cy": 49,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 29,
        "cy": 49,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 30,
        "cy": 49,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 31,
        "cy": 49,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 32,
        "cy": 49,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 33,
        "cy": 49,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 34,
        "cy": 49,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 35,
        "cy": 49,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 36,
        "cy": 49,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 37,
        "cy": 49,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 38,
        "cy": 49,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 39,
        "cy": 49,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 40,
        "cy": 49,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 41,
        "cy": 49,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 42,
        "cy": 49,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 43,
        "cy": 49,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 44,
        "cy": 49,
        "r": 1,
        "colour": 8
    },
    {
        "cx": 45,
        "cy": 49,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 46,
        "cy": 49,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 47,
        "cy": 49,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 48,
        "cy": 49,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 49,
        "cy": 49,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 50,
        "cy": 49,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 51,
        "cy": 49,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 52,
        "cy": 49,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 17,
        "cy": 50,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 18,
        "cy": 50,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 19,
        "cy": 50,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 20,
        "cy": 50,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 21,
        "cy": 50,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 22,
        "cy": 50,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 23,
        "cy": 50,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 24,
        "cy": 50,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 25,
        "cy": 50,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 26,
        "cy": 50,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 27,
        "cy": 50,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 28,
        "cy": 50,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 29,
        "cy": 50,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 30,
        "cy": 50,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 31,
        "cy": 50,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 32,
        "cy": 50,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 33,
        "cy": 50,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 34,
        "cy": 50,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 35,
        "cy": 50,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 36,
        "cy": 50,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 37,
        "cy": 50,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 38,
        "cy": 50,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 39,
        "cy": 50,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 40,
        "cy": 50,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 41,
        "cy": 50,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 42,
        "cy": 50,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 43,
        "cy": 50,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 44,
        "cy": 50,
        "r": 1,
        "colour": 8
    },
    {
        "cx": 45,
        "cy": 50,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 46,
        "cy": 50,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 47,
        "cy": 50,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 48,
        "cy": 50,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 49,
        "cy": 50,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 50,
        "cy": 50,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 51,
        "cy": 50,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 15,
        "cy": 51,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 17,
        "cy": 51,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 18,
        "cy": 51,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 19,
        "cy": 51,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 20,
        "cy": 51,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 21,
        "cy": 51,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 22,
        "cy": 51,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 23,
        "cy": 51,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 24,
        "cy": 51,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 25,
        "cy": 51,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 26,
        "cy": 51,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 27,
        "cy": 51,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 28,
        "cy": 51,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 29,
        "cy": 51,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 30,
        "cy": 51,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 31,
        "cy": 51,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 32,
        "cy": 51,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 33,
        "cy": 51,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 34,
        "cy": 51,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 35,
        "cy": 51,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 36,
        "cy": 51,
        "r": 1,
        "colour": 24
    },
    {
        "cx": 37,
        "cy": 51,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 38,
        "cy": 51,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 39,
        "cy": 51,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 40,
        "cy": 51,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 41,
        "cy": 51,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 42,
        "cy": 51,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 43,
        "cy": 51,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 44,
        "cy": 51,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 45,
        "cy": 51,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 46,
        "cy": 51,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 47,
        "cy": 51,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 48,
        "cy": 51,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 49,
        "cy": 51,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 15,
        "cy": 52,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 16,
        "cy": 52,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 17,
        "cy": 52,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 18,
        "cy": 52,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 19,
        "cy": 52,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 20,
        "cy": 52,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 21,
        "cy": 52,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 22,
        "cy": 52,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 23,
        "cy": 52,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 24,
        "cy": 52,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 25,
        "cy": 52,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 26,
        "cy": 52,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 27,
        "cy": 52,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 28,
        "cy": 52,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 29,
        "cy": 52,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 30,
        "cy": 52,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 31,
        "cy": 52,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 32,
        "cy": 52,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 33,
        "cy": 52,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 34,
        "cy": 52,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 35,
        "cy": 52,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 36,
        "cy": 52,
        "r": 1,
        "colour": 27
    },
    {
        "cx": 37,
        "cy": 52,
        "r": 1,
        "colour": 25
    },
    {
        "cx": 38,
        "cy": 52,
        "r": 1,
        "colour": 34
    },
    {
        "cx": 39,
        "cy": 52,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 40,
        "cy": 52,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 41,
        "cy": 52,
        "r": 1,
        "colour": 12
    },
    {
        "cx": 42,
        "cy": 52,
        "r": 1,
        "colour": 13
    },
    {
        "cx": 43,
        "cy": 52,
        "r": 1,
        "colour": 25
    },
    {
        "cx": 44,
        "cy": 52,
        "r": 1,
        "colour": 57
    },
    {
        "cx": 45,
        "cy": 52,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 46,
        "cy": 52,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 47,
        "cy": 52,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 15,
        "cy": 53,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 16,
        "cy": 53,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 17,
        "cy": 53,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 18,
        "cy": 53,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 19,
        "cy": 53,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 20,
        "cy": 53,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 21,
        "cy": 53,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 22,
        "cy": 53,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 23,
        "cy": 53,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 24,
        "cy": 53,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 25,
        "cy": 53,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 26,
        "cy": 53,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 27,
        "cy": 53,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 28,
        "cy": 53,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 29,
        "cy": 53,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 30,
        "cy": 53,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 31,
        "cy": 53,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 32,
        "cy": 53,
        "r": 1,
        "colour": 5
    },
    {
        "cx": 33,
        "cy": 53,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 34,
        "cy": 53,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 35,
        "cy": 53,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 36,
        "cy": 53,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 37,
        "cy": 53,
        "r": 1,
        "colour": 53
    },
    {
        "cx": 39,
        "cy": 53,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 40,
        "cy": 53,
        "r": 1,
        "colour": 12
    },
    {
        "cx": 15,
        "cy": 54,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 16,
        "cy": 54,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 17,
        "cy": 54,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 18,
        "cy": 54,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 19,
        "cy": 54,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 20,
        "cy": 54,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 21,
        "cy": 54,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 22,
        "cy": 54,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 23,
        "cy": 54,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 24,
        "cy": 54,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 25,
        "cy": 54,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 26,
        "cy": 54,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 27,
        "cy": 54,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 28,
        "cy": 54,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 29,
        "cy": 54,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 30,
        "cy": 54,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 31,
        "cy": 54,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 32,
        "cy": 54,
        "r": 1,
        "colour": 40
    },
    {
        "cx": 35,
        "cy": 54,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 36,
        "cy": 54,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 37,
        "cy": 54,
        "r": 1,
        "colour": 6
    },
    {
        "cx": 14,
        "cy": 55,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 15,
        "cy": 55,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 16,
        "cy": 55,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 17,
        "cy": 55,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 18,
        "cy": 55,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 19,
        "cy": 55,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 20,
        "cy": 55,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 21,
        "cy": 55,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 22,
        "cy": 55,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 23,
        "cy": 55,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 28,
        "cy": 55,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 30,
        "cy": 55,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 31,
        "cy": 55,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 32,
        "cy": 55,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 37,
        "cy": 55,
        "r": 1,
        "colour": 7
    },
    {
        "cx": 12,
        "cy": 56,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 13,
        "cy": 56,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 14,
        "cy": 56,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 15,
        "cy": 56,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 16,
        "cy": 56,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 17,
        "cy": 56,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 18,
        "cy": 56,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 19,
        "cy": 56,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 20,
        "cy": 56,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 21,
        "cy": 56,
        "r": 1,
        "colour": 4
    },
    {
        "cx": 12,
        "cy": 57,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 13,
        "cy": 57,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 14,
        "cy": 57,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 15,
        "cy": 57,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 16,
        "cy": 57,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 17,
        "cy": 57,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 18,
        "cy": 57,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 19,
        "cy": 57,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 20,
        "cy": 57,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 21,
        "cy": 57,
        "r": 1,
        "colour": 19
    },
    {
        "cx": 11,
        "cy": 58,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 12,
        "cy": 58,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 13,
        "cy": 58,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 14,
        "cy": 58,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 15,
        "cy": 58,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 17,
        "cy": 58,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 18,
        "cy": 58,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 19,
        "cy": 58,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 20,
        "cy": 58,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 21,
        "cy": 58,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 10,
        "cy": 59,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 11,
        "cy": 59,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 12,
        "cy": 59,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 13,
        "cy": 59,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 20,
        "cy": 59,
        "r": 1,
        "colour": 1
    },
    {
        "cx": 7,
        "cy": 60,
        "r": 1,
        "colour": 2
    },
    {
        "cx": 8,
        "cy": 60,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 9,
        "cy": 60,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 10,
        "cy": 60,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 11,
        "cy": 60,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 7,
        "cy": 61,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 10,
        "cy": 61,
        "r": 1,
        "colour": 3
    },
    {
        "cx": 11,
        "cy": 61,
        "r": 1,
        "colour": 3
    }
]